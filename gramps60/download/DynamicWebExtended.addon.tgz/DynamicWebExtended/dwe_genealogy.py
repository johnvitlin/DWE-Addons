# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

"""
Shared genealogical interpretation helpers for Dynamic Web Extended.

This module contains DWE-specific rules that may be reused by the
Calendar, Records, and other features.
"""
# centralises rules and calculations that deviate from the standard Gramps rule.

from gramps.gen.lib import Date, EventType
from gramps.gen.utils.db import get_birth_or_fallback, get_death_or_fallback


# Event selection and fallback rules

def get_dwe_marriage_event(db, family):
    """
    Return a Marriage event, or an Alternate Marriage as a fallback.

    Engagements are deliberately excluded.

    Only events with a Family or Primary reference role are eligible.
    """
    alternate_marriage = None

    for event_ref in family.get_event_ref_list():
        if not (
            event_ref.get_role().is_family()
            or event_ref.get_role().is_primary()
        ):
            continue

        event = db.get_event_from_handle(event_ref.ref)
        if event is None:
            continue

        event_type = event.get_type()

        if event_type == EventType.MARRIAGE:
            return event

        if (
            event_type == EventType.MARR_ALT
            and alternate_marriage is None
        ):
            alternate_marriage = event

    return alternate_marriage


def get_dwe_birth_event(db, person):
    """
    Return a Birth event, falling back to Christening
    when no Birth event is available.
    """
    return get_birth_or_fallback(db, person)


def get_dwe_death_event(db, person):
    """
    Return a Death event, using the Gramps fallback rules.
    """
    return get_death_or_fallback(db, person)


# Living-person calculations

def probably_not_living_from_marriages(
    person, db, reference_year,
    max_age=110, min_marriage_age=12
):
    """
    Return True if a dated marriage provides evidence that a
    person cannot plausibly still be living in reference_year.

    Uses conservative assumptions:
      - Maximum plausible lifespan: 110 years
      - Minimum marriage age: 12 years

    A marriage provides evidence of age, but does not establish
    that a person is living.

    Undated marriages and marriages without a usable year
    are ignored.
    """
    if person is None:
        return False

    for family_handle in person.get_family_handle_list():
        family = db.get_family_from_handle(family_handle)
        if family is None:
            continue

        marriage = get_dwe_marriage_event(db, family)
        if marriage is None:
            continue

        marriage_date = marriage.get_date_object()

        # Only use unmodified dates as historical evidence.
        # Ignore approximate, before/after, range and span dates.
        if marriage_date.get_modifier() != Date.MOD_NONE:
            continue

        marriage_year = marriage_date.get_year()

        if marriage_year <= 0:
            continue

        # Earliest plausible birth year is marriage year minus
        # the minimum marriage age.
        latest_birth_year = marriage_year - min_marriage_age

        # Even with the most generous assumptions, this person
        # would have exceeded the maximum plausible lifespan.
        if reference_year > latest_birth_year + max_age:
            return True

    return False


# Parent-child relationship interpretation
    # none yet

# Family and sibling relationships
    # none yet

# Kinship calculations
    # none yet