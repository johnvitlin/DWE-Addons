# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

"""
Calendar support for Dynamic Web Extended.

Date classification for birthdays and anniversaries.
"""

from gramps.gen.lib import Date, EventType
from dwe_genealogy import (
    get_dwe_birth_event,
    get_dwe_death_event,
)

from dwe_genealogy import get_dwe_marriage_event


def classify_calendar_date(date):
    """
    Classify a Gramps date for calendar use.

    Returns:
        ("day", month, day)   - known month and day
        ("month", month, 0)   - known month, day unknown
        ("omit", 0, 0)        - unsuitable for a monthly calendar

    The original Date object is retained by the caller so its
    qualifier and complete date can be displayed.
    """
    if date is None or date.is_empty() or not date.is_valid():
        return ("omit", 0, 0)

    if date.get_modifier() not in (Date.MOD_NONE, Date.MOD_ABOUT):
        return ("omit", 0, 0)

    month = date.get_month()
    day = date.get_day()

    if not 1 <= month <= 12:
        return ("omit", 0, 0)

    if day == 0:
        return ("month", month, 0)

    return ("day", month, day)


def get_person_calendar_events(db, person):
    """
    Collect qualifying birth and death calendar events for a person.

    Preserve the actual Gramps event type when a fallback event
    (such as Christening or Burial) is selected.
    """
    entries = []

    for category, get_event in (
        ("birth", get_dwe_birth_event),
        ("death", get_dwe_death_event),
    ):
        event = get_event(db, person)
        if event is None:
            continue

        date = event.get_date_object()
        precision, month, day = classify_calendar_date(date)

        if precision == "omit":
            continue

        entries.append({
            "event_gid": event.get_gramps_id(),
            "type": str(event.get_type()),
            "category": category,
            "precision": precision,
            "month": month,
            "day": day,
            "year": date.get_year(),
            "description": event.get_description(),
        })

    return entries


def get_family_calendar_events(db, family):
    """
    Collect all qualifying Marriage and Alternative Marriage events.

    Engagements are excluded. Each distinct event is included once,
    even when two events have the same date.
    """
    entries = []
    seen_events = set()

    for event_ref in family.get_event_ref_list():
        if not (
            event_ref.get_role().is_family()
            or event_ref.get_role().is_primary()
        ):
            continue

        if event_ref.ref in seen_events:
            continue

        event = db.get_event_from_handle(event_ref.ref)
        if event is None:
            continue

        if event.get_type() not in (
            EventType.MARRIAGE,
            EventType.MARR_ALT,
        ):
            continue

        seen_events.add(event_ref.ref)

        date = event.get_date_object()
        precision, month, day = classify_calendar_date(date)

        if precision == "omit":
            continue

        entries.append({
            "event_gid": event.get_gramps_id(),
            "type": str(event.get_type()),
            "precision": precision,
            "month": month,
            "day": day,
            "year": date.get_year(),
            "description": event.get_description(),
        })

    return entries