# -*- coding: utf-8 -*-
#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2014 Pierre Bélissent
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#

register(REPORT,
	id = 'DynamicWebExtended',
	name = _("Dynamic Web Extended"),
	description = _("Produces an extended dynamic web report for genealogy"),
    help_url = "https://github.com/johnvitlin/DWE-Addons/blob/main/README.md",
	version = '0.3.9',
	
	gramps_target_version = "6.0",
    # gramps_target_version = "6.0",
    
	status = STABLE,
	fname = 'DynamicWebExtended.py',
	category = CATEGORY_WEB,
	reportclass = 'DynamicWebReport',
	optionclass = 'DynamicWebOptions',
	report_modes = [REPORT_MODE_GUI, REPORT_MODE_CLI],
	authors = ['Pierre Bélissent', 'John Vitlin'],
	require_active = True  # set true because the 'filter' option can require an active person
)
