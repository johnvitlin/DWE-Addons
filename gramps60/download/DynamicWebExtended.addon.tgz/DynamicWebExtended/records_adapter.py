# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

"""
Restricted database view for DWE Records.

Limits record-holder iteration to the individuals and families
included in the generated website.
"""

# Its responsibilities will be to:
# - Use copies of person and family, not the original objects
# - Intercept the methods used by librecords.py
# - Restrict the individuals and families eligible for record calculations to those present in DWE
# - Restrict relationships so excluded children and grandchildren are not counted.
# - Delegate permitted lookups to DWE's privacy-aware database.
# - Support the unfiltered-person lookup required internally by find_records(), without exporting that information.

from gramps.gen.lib import Family, Person


class RecordsDbAdapter:
    """Read-only database view for Records calculations."""

    def __init__(self, database, person_handles, family_handles):
        self._database = database
        self._person_handles = set(person_handles)
        self._family_handles = set(family_handles)

    def iter_person_handles(self):
        """Iterate over individuals included in the website."""
        return iter(self._person_handles)

    def iter_families(self):
        """Iterate over families included in the website."""
        for handle in self._family_handles:
            family = self.get_family_from_handle(handle)
            if family is not None:
                yield family

    def get_person_from_handle(self, handle):
        """Return a person with excluded family references removed."""
        if handle not in self._person_handles:
            return None

        person = self._database.get_person_from_handle(handle)
        if person is None:
            return None

        person_copy = Person()
        person_copy.unserialize(person.serialize())

        family_handles = [
            family_handle
            for family_handle in person_copy.get_family_handle_list()
            if family_handle in self._family_handles
        ]
        person_copy.set_family_handle_list(family_handles)

        return person_copy

    def get_unfiltered_person(self, handle):
        """Return an original person only if included in the website."""
        if handle not in self._person_handles:
            return None

        return self._database.get_unfiltered_person(handle)

    def get_family_from_handle(self, handle):
        """Return a family with excluded child references removed."""
        if handle not in self._family_handles:
            return None

        family = self._database.get_family_from_handle(handle)
        if family is None:
            return None

        family_copy = Family()
        family_copy.unserialize(family.serialize())

        child_refs = [
            child_ref
            for child_ref in family_copy.get_child_ref_list()
            if child_ref.ref in self._person_handles
        ]
        family_copy.set_child_ref_list(child_refs)

        if family_copy.get_father_handle() not in self._person_handles:
            family_copy.set_father_handle(None)

        if family_copy.get_mother_handle() not in self._person_handles:
            family_copy.set_mother_handle(None)

        return family_copy

    def __getattr__(self, name):
        """Delegate other database operations to DWE's database."""
        return getattr(self._database, name)