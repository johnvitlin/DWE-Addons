"""
PDF thumbnail generation using Poppler's pdftoppm.
"""

import logging
import os
import shutil
import subprocess
import tempfile

from functools import lru_cache
from gramps.gen.const import THUMBSCALE, THUMBSCALE_LARGE, SIZE_LARGE
from gramps.gen.plug import Thumbnailer
from pathlib import Path

LOG = logging.getLogger(".thumbnail")

# Cache the Poppler executable path to avoid repeated searches.
@lru_cache(maxsize=1)
def find_pdftoppm():
    """Locate Poppler's pdftoppm executable."""

    configured = os.environ.get("PDFTHUMBNAILER_PDFTOPPM")

    if configured:
        if os.path.isfile(configured):
            return configured
        LOG.warning(
            "Configured Poppler executable not found: %s",
            configured,
        )

    executable = shutil.which("pdftoppm")
    if executable:
        return executable

    # Search common Windows Poppler installation directories.
    if os.name == "nt":
        roots = [
            Path("C:/Poppler"),
            Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Poppler",
            Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")) / "Poppler",
            Path("C:/Tools/Poppler"),
        ]

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            roots.append(Path(local_app_data) / "Poppler")

        for root in roots:
            candidates = [
                root / "Library/bin/pdftoppm.exe",
                root / "bin/pdftoppm.exe",
            ]

            if root.is_dir():
                for version_dir in root.iterdir():
                    if version_dir.is_dir():
                        candidates.extend([
                            version_dir / "Library/bin/pdftoppm.exe",
                            version_dir / "bin/pdftoppm.exe",
                        ])

            for candidate in candidates:
                if candidate.is_file():
                    return str(candidate)

    return None

class PDFThumbnailer(Thumbnailer):
    """Generate a PNG thumbnail from the first page of a PDF."""

    def is_supported(self, mime_type):
        return mime_type == "application/pdf"

    def run(self, mime_type, src_file, dest_file, size, rectangle):
        if not self.is_supported(mime_type):
            return False

        pdftoppm = find_pdftoppm()

        if not pdftoppm:
            LOG.warning("Poppler pdftoppm executable not found")
            return False

        thumbscale = (
            THUMBSCALE_LARGE if size == SIZE_LARGE else THUMBSCALE
        )

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                output_prefix = os.path.join(temp_dir, "pdf-thumb")
                output_png = output_prefix + ".png"

                command = [
                    pdftoppm,
                    "-f", "1",
                    "-l", "1",
                    "-singlefile",
                    "-scale-to", str(int(thumbscale)),
                    "-png",
                    src_file,
                    output_prefix,
                ]

                subprocess.run(
                    command,
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    timeout=30,
                )

                os.replace(output_png, dest_file)

            return True

        except (OSError, subprocess.SubprocessError) as err:
            LOG.warning("PDF thumbnail generation failed: %s", err)
            return False
        