from gramps.gen.const import GRAMPS_LOCALE as glocale

_ = glocale.translation.gettext

register(  # pyright: ignore[reportUndefinedVariable]
    THUMBNAILER,  # pyright: ignore[reportUndefinedVariable]
    id="pdfthumbnailer",
    name=_("PDF Thumbnailer"),
    description=_("Generate PDF thumbnails using Poppler"),
    version="0.1.0",
    gramps_target_version="6.0",
    status=STABLE,  # pyright: ignore[reportUndefinedVariable]
    order=START,  # pyright: ignore[reportUndefinedVariable]
    fname="PDFThumbnailer.py",
    thumbnailer="PDFThumbnailer",
    authors=["Local development"],
)
