# Guide to this Website

Welcome to this family history website.

This website presents information about individuals, families, relationships, events, places and historical records. It was created using **Dynamic Web Extended (DWE)**, an extension of the Gramps Dynamic Web Report.

## Finding people and families

Use the website's menus and indexes to find people, families, places and other information.

Names and other highlighted items may be clickable, allowing you to follow connections and explore the family history.

## Exploring a person's history

Depending on the information available, a person's page may include several ways of exploring their life and family relationships.

### Events

View events associated with a person, such as births, marriages, residences and deaths.

Explore a broader chronology that may include events involving parents, siblings, spouses and children.

View other participants in events, such as witnesses and celebrants.

### Lifespans

See a graphical comparison of people's lifetimes, helping you understand which family members lived during the same periods.

### Tree Viewer

Explore family relationships using an interactive family tree. Select individuals to investigate their ancestors, descendants and other connections.

### Tracking

Explore connections and relationships between selected individuals.

### Story

Read a narrative introduction to a person's life, where one has been provided.

### Why Me

Read an explanation of why a particular person is included or significant within the family history, where available.

Not every feature will appear for every individual.

## Photographs, documents and sources

Where available, the website may include photographs, historical documents, notes and references to research sources.

These can provide additional context and help explain how family relationships and historical details were established.

## Viewing the website on your computer

Some interactive features require the website to be accessed through a local web server rather than by opening its HTML files directly.

If the website includes a Windows file named **View report locally.bat**, you can double-click it to open the website locally.

An internet connection may still be needed for some external services, such as online maps.

## About the information

Family history research is an ongoing process. Some dates, relationships and other details may be uncertain or incomplete.

Where possible, consult the accompanying notes and sources for additional information.

---

*This website was generated using Dynamic Web Extended.*
