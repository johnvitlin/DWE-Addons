@echo off
    cd /d "%~dp0"

    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 "view_report.py"
        if errorlevel 1 pause
        goto :eof
    )

    where python >nul 2>nul
    if not errorlevel 1 (
        python "view_report.py"
        if errorlevel 1 pause
        goto :eof
    )

    echo.
    echo Unable to start the Dynamic Web report.
    echo.
    echo Python could not be found on this computer.
    echo.
    echo See Local viewing.txt for instructions.
    echo.
    pause
    