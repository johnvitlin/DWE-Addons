"""Starting a local web server for this Dynamic Web report."""

from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
import threading
import webbrowser


report_dir = Path(__file__).resolve().parent
os.chdir(report_dir)

# Port 0 tells the operating system to choose an unused local port.
server = ThreadingHTTPServer(
    ("127.0.0.1", 0),
    SimpleHTTPRequestHandler
)

port = server.server_address[1]
url = f"http://127.0.0.1:{port}/"

print()
print("Dynamic Web report")
print("==================")
print()
print("The report is available at:")
print()
print(f"    {url}")
print()
print("Your web browser should open automatically.")
print()
print("Keep this window open while viewing the report.")
print("Close this window, or press Ctrl+C, when finished.")
print()

# Give the server a moment to start before opening the browser.
threading.Timer(
    0.5,
    lambda: webbrowser.open(url)
).start()

try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
