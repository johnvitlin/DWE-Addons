﻿// Gramps - a GTK+/GNOME based genealogy program
//
// Copyright (C) 2021 John Vitlin
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// functions for Dynamic Web modifications
//



//the following section is for use with event extension

function storageAvailable(type) {
    // JV taken from https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
    // example use: if (storageAvailable('localStorage')) {...
    // checks if local storage is enabled in the browser so that checkbox values can be stored
    let storage;
    try {
        storage = window[type];
        let x = '__storage_test__';
        storage.setItem(x, x);
        storage.removeItem(x);
        return true;
    } catch (e) {
        return e instanceof DOMException && (
            // .code property is deprecated, so commented out Dec 2024
            // everything except Firefox
            //e.code === 22 ||
            // Firefox
            //e.code === 1014 ||
            // test name field too, because code might not be present
            // everything except Firefox
            e.name === 'QuotaExceededError' ||
            // Firefox
            e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
            // acknowledge QuotaExceededError only if there's something already stored
            (storage && storage.length !== 0);
    }
}

function update_event_rows() {
    // evaluates all the filters together before deciding whether to show each row.
    const limitLifespan = $("#lifespan").is(':checked');
    const showParticipation = $("#EEparticipationCheck").is(':checked');

    $("#extended_events tbody tr").each(function () {
        const row = $(this);
        const kind = $.trim(row.find("td").eq(2).text());
        const inLifespan = $.trim(row.find("td").eq(1).text()) === "true";
        const participation = row.attr("data-participation") === "true";

        let visible = true;

        // Apply the vital-event filters.
        if (["child", "spouse", "sibling", "parent"].includes(kind)) {
            visible = $("#vital_" + kind).is(':checked');
        }

        // Apply the lifespan limit to relatives' vital events
        // and participation-only events.
        if (limitLifespan &&
            (["child", "spouse", "sibling", "parent"].includes(kind) || participation) &&
            !inLifespan) {
            visible = false;
        }

        // Apply the participation-event filter.
        if (participation && !showParticipation) {
            visible = false;
        }

        row.toggle(visible);
    });
}

function lifespan_clicked() {
    const checked = $("#lifespan").is(':checked');
    update_dwritem('dwr_values', 'lifespan', checked);
    update_event_rows();
}

function vital_clicked(kind) {
    const checked = $("#vital_" + kind).is(':checked');
    update_dwritem('dwr_values', 'vital_' + kind, checked);
    update_event_rows();
}

function EEparticipation_clicked() {
    const checked = $("#EEparticipationCheck").is(':checked');
    update_dwritem('dwr_values', 'EEparticipationCheck', checked);
    update_event_rows();
}

function EEnote_clicked() {
    const checked = $("#EEnoteCheck").is(':checked');
    update_dwritem('dwr_values', 'EEnoteCheck', checked);
    $('#extended_events .ee-notes').toggle(checked);
}

function EEparticipants_clicked() {
    const checked = $("#EEparticipantsCheck").is(':checked');
    update_dwritem('dwr_values', 'EEparticipantsCheck', checked);
    $('#extended_events .ee-participants').toggle(checked);
}

let initial_dwrvalues = {  // JV to define initial values if they don't exist in local storage yet.
    vital_child: true,
    vital_spouse: true,
    vital_sibling: true,
    vital_parent: true,
    lifespan: false,
    EEparticipantsCheck: true,
    EEparticipationCheck: true,
    EEnoteCheck: true
};

function set_dwrstorage(key, obj) {  // JV
    localStorage.setItem(key, JSON.stringify(obj));
}

function get_dwrstorage(key) {  // JV get the localstorage called key, set initial if not found
    return JSON.parse(localStorage.getItem(key)) || initial_dwrvalues;
}

function update_dwritem(key, property, value) {  // JV
    if (storageAvailable('localStorage')) {
        let obj = get_dwrstorage(key);
        obj[property] = value;
        set_dwrstorage(key, obj);
    }
}

// alert("dwr B loading!");

window.onload = function () {  // JV get the values from local storage and sync display
    if ($('#extended_events').length > 0) { // if page has extended events table
        if (storageAvailable('localStorage')) {
            let stored_dwrvalues = get_dwrstorage('dwr_values');
            //alert('stored_dwrvalues is ' + JSON.stringify(stored_dwrvalues));
            $.each(stored_dwrvalues, function (key, value) {
                $("#" + key).prop("checked", value);  // set the checkbox
            });
            // fire fns to sync extended events display
            update_event_rows();
            EEnote_clicked();
            EEparticipants_clicked();
        }
    }
};
