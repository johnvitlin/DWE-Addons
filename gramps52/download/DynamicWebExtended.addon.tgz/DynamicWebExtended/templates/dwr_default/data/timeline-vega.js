// Gramps - a GTK+/GNOME based genealogy program
/*
 Copyright (C) 2026- John Vitlin 

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
*/

function createTimelineVegaSpec(
    peoplevalues,
    eventvalues,
    defaultFontHeight,
    timelineLabels
) {

     // Conditions used to position person labels.
    const bothDatesRight =  // if both dates are to the right of the midpoint
        "datum.born_adjusted && datum.died_adjusted && " +
        "scale('xscale', datum.born_adjusted) > chartMidpoint && " +
        "scale('xscale', datum.died_adjusted) > chartMidpoint";

    const deathOnlyRight =
        "datum.died_adjusted && !datum.born_adjusted && " +
        "scale('xscale', datum.died_adjusted) > chartMidpoint";

    const birthOnlyRight =
        "datum.born_adjusted && !datum.died_adjusted && " +
        "scale('xscale', datum.born_adjusted) > chartMidpoint";

    const marriageTooltipExpr =
        JSON.stringify(timelineLabels.marriage) +
        " + ': ' + (datum.date_display || '?') + " +
        "(datum.place_display ? ', ' + datum.place_display : '')";

    // Keep relationship colours consistent between Lifespans charts.
    // Colour-vision-accessible colours based on Paul Tol's Bright palette.
    const roleColours = {
        parent: "#4477AA",
        sibling: "#66CCEE",
        me: "#AA3377",
        spouse: "#EE6677",
        child: "#228833"
    };

    const presentRoles = [...new Set(peoplevalues.map(person => person.kind))];

    const roleColourRange = presentRoles.map(
        role => roleColours[role] || "#7f7f7f"  // Grey fallback colour for any unrecognised role.
    );

    return {
        // JV, with a bit of help from ChatGPT
        // Vega specifications are normally JSON and cannot contain comments.
        // This specification is kept as JavaScript so explanatory comments can be retained.

        $schema: 'https://vega.github.io/schema/vega/v6.json',
        description: "A timeline visualization of family member lifespans",
        background: "white",  // to fix a transparent background causing problems in the png download

        signals: [
            {
                "name": "fontHeight",  // bind a range slider to get user input
                "value": defaultFontHeight,
                // "bind": {"input": "range", "min": 8, "max": 24, "step": 1}
                },
            {
                name: "width",
                update: "containerSize()[0] * 0.9",
                on: [
                    {
                        events: "container:resize",  // Calculate width dynamically with resize event
                        update: "containerSize()[0] * 0.9"
                    }
                ]
            },
            {
                name: "timelineBarHeight",  // physical thickness of the lifespan bar
                value: 4
            },
            {
                name: "timelineBarCentre",  // where the birth/death/marriage markers meet it
                update: "timelineBarHeight / 2"
            },
            {name: "personLabelOffset", value: -3},  // independent gap of label above the bar
            {name: "personOffset", value: 10},  // vertical separation between person data
            {name: "personHeight", value: 25},
            {name: "topAxisOffset", value: 25},
            {name: "peopleCount", value: peoplevalues.length},  // how many people to draw

            {name: "undatedMarriageSpacing", value: 20},
            {name: "undatedMarriageMargin", value: 15},
            {
                name: "undatedMarriageCount",
                update: "length(data('undatedMarriageEvents'))"
            },
            {
                name: "undatedMarriageWidth",  // use a dynamically calculated width for the undated-marriages area
                update: "undatedMarriageCount > 0 ? " +
                        "undatedMarriageCount * undatedMarriageSpacing + " +
                        "2 * undatedMarriageMargin : 0"
            },

            {"name": "chartMidpoint", update: "width / 2"}, // Midpoint of the chart (used for label aligning)
            {"name": "peopleHeight", "update": "peopleCount * (personOffset + personHeight)"},
            {"name": "labelFontSize", update: "fontHeight"}, // font size for labels (set as an option)
            {"name": "axisFontSize", value: 14}, // font size for axis values (could set this as an option)
            {"name": "hovered", value: null, 
                on: [
                {"events": "@timebar:mouseover", "update": "datum"},
                {"events": "@timebar:mouseout", "update": "null"},
                {"events": "@born-marker:mouseover", "update": "datum"},
                {"events": "@born-marker:mouseout", "update": "null"},
                {"events": "@died-marker:mouseover", "update": "datum"},
                {"events": "@died-marker:mouseout", "update": "null"},
                {"events": "@personbar:mouseover", "update": "datum"},
                {"events": "@personbar:mouseout", "update": "null"},
                {"events": "@personlabel:mouseover", "update": "datum"},
                {"events": "@personlabel:mouseout", "update": "null"}
            ]},
            {
                name: "showMarriages",
                value: true
            },
            {
                name: "showTimeHints",
                value: true
            },

        ],
        
        // set data rectangle dimensions
        height: {signal: "peopleHeight"},
        padding: 5,
        autosize: {"type": "pad", "resize": true},  // Enable resizing

        data: [
            {
                name: "people",
                // born_display, died_display are used for dates
                // born_adjusted, died_adjusted in the data are parsed dates used for timeline bars and markers
                format: {type: "json", parse: {"born_adjusted": "date", "died_adjusted": "date"}, copy: true},
                values: peoplevalues,
                transform: [
                    {
                        type: "formula", as: "plabel1",  // concatenate some fields as label for a timeline
                        expr: "datum.name + '  (' + " +
                                "(datum.pc_reln === 'subject' ? " +
                                JSON.stringify(timelineLabels.subject) +
                                " : datum.pc_reln) + ')'"
                    },
                    {  // to show dates and places for hover
                        type: "formula", as: "birth_tooltip",
                        expr: "(datum.born_display || '?') + " +
                                "(datum.born_place ? ', ' + datum.born_place : '')"
                    },
                    {
                        type: "formula", as: "death_tooltip",
                        expr: "(datum.died_display || '?') + " +
                                "(datum.died_place ? ', ' + datum.died_place : '')"
                    },
                ]
            },
            {
                name: "hasbirth",
                source: "people",
                transform: [{type: "filter", expr: "datum['born_adjusted'] != null"}]
            },
            {
                name: "hasdeath",
                source: "people",
                transform: [{type: "filter", expr: "datum['died_adjusted'] != null"}]
            },
            
            {
                name: "peopleEvents",
                // Marriage events, including those without a usable date.
                // Other event types may be supported in future.
                format: {type: "json", parse: {"date_adjusted": "date"}},
                values: eventvalues,
            },
            {
                name: "visibleMarriageEvents",  // used to show marriage marks depending on the showmarriage value
                source: "peopleEvents",
                transform: [
                    {
                        type: "filter",
                        expr: "showMarriages && datum.type === 'marriage'"
                    }
                ]
            },
            {
                name: "datedMarriageEvents",
                source: "visibleMarriageEvents",
                transform: [
                    {
                        type: "filter",
                        expr: "isValid(datum.date_adjusted)"
                    }
                ]
            },
            {
                name: "undatedMarriageEvents",
                source: "visibleMarriageEvents",
                transform: [
                    {
                        type: "filter",
                        expr: "!isValid(datum.date_adjusted)"
                    },
                    {
                        type: "window",  // assign each undated marriage a sequential number, starting at 1
                        ops: ["row_number"],
                        as: ["undatedIndex"]
                    }
                ]
            }

        ],// end of top level data def

        scales: [
            {
                name: "xscale",
                type: "time",
                // range: "width",
                "range": [  // When undated marriages exist, the dated timeline begins further to the right
                    {"signal": "undatedMarriageWidth"},
                    {"signal": "width"}
                ],
                round: true,
                domain: {
                    fields: [
                        // any dated event that can be plotted should contribute to the x-domain
                        {data: "people", field: "born_adjusted"},
                        {data: "people", field: "died_adjusted"},
                        {data: "peopleEvents", field: "date_adjusted"}
                    ]
                }
            },
            {
                name: "yscale",
                type: "band",
                range: [0, {signal: "peopleHeight"}],
                domain: {data: "people", field: "timeline_id"}  // timeline_id is unique to person, use here so each person has a band
                // timebars with the same timeline id will overlay each other on the y scale
            },  
            {
                name: "famscale",  // not used yet
                type: "band",
                range: [0, {signal: "peopleHeight"}],
                domain: {data: "people", field: "fam_handle"},
                padding: 0.1
            },
            {
                name: "kindscale",
                type: "ordinal",
                domain: presentRoles,
                range: roleColourRange
            }
        ],
        axes: [
            {orient: "bottom", scale: "xscale", format: "%Y",
                "encode": {
                    "labels": {
                        "update": {
                        "fontSize": {"signal": "axisFontSize"}  // Use the signal
                        }
                    }
                    }    
            },
            {orient: "top", scale: "xscale", format: "%Y", offset: {signal: "topAxisOffset"},
            "encode": {
                "labels": {
                    "update": {
                    "fontSize": {"signal": "axisFontSize"}  // Use the signal
                    }
                }
                }                  
            }
        ],
        legends: [
            {
                fill: "kindscale",
                title: timelineLabels.role,
                orient: "right",
                titleFontSize: {"signal": "axisFontSize"},
                labelFontSize: {"signal": "axisFontSize"},
                padding: 4,
                encode: {
                    symbols: {
                        enter: {
                            size: {value: 50}
                        }
                    },
                    labels: {
                        update: {
                            text: {
                                signal:
                                    "datum.label === 'me' ? " +
                                    JSON.stringify(timelineLabels.subject) +
                                    " : datum.label === 'parent' ? " +
                                    JSON.stringify(timelineLabels.parent) +
                                    " : datum.label === 'sibling' ? " +
                                    JSON.stringify(timelineLabels.sibling) +
                                    " : datum.label === 'spouse' ? " +
                                    JSON.stringify(timelineLabels.spouse) +
                                    " : datum.label === 'child' ? " +
                                    JSON.stringify(timelineLabels.child) +
                                    " : datum.label"
                            }
                        }
                    }
                }
            }
        ],
        marks: [
            {
                name: "born-marker",
                type: "symbol",
                from: {data: "hasbirth"},
                encode: {
                    enter: {
                        // x: {scale: "xscale", field: "born_adjusted", offset: 4},  // offset point so lhs lines up
                        size: {signal: "datum.died_adjusted ? 100 : 200"},  // conditional size, more visible if no died, ie no timebar
                        y: {scale: "yscale", field: "timeline_id", offset: {signal: "timelineBarCentre"}},
                        fill: {scale: "kindscale", field: "kind"},
                        shape: {value: "triangle-right"}
                    },
                    update: {
                        x: {scale: "xscale", field: "born_adjusted", offset: 4},  // offset point so lhs lines up
                    },
                }
            },
            {
                name: "died-marker",
                type: "symbol",
                from: {data: "hasdeath"},
                encode: {
                    enter: {
                        // x: {scale: "xscale", field: "died_adjusted", offset: -4},
                        size: {signal: "datum.born_adjusted ? 100 : 200"},  // Conditional size, more visible if no born
                        y: {scale: "yscale", field: "timeline_id", offset: {signal: "timelineBarCentre"}},
                        fill: {scale: "kindscale", field: "kind"},
                        shape: {value: "triangle-left"}
                    },
                    update: {
                        x: {scale: "xscale", field: "died_adjusted", offset: -4},
                    }
                }
            },
            {
                name: "timebar",
                type: "rect",
                from: {data: "people"},
                encode: {
                    enter: {
                        x: {scale: "xscale", field: "born_adjusted"},  // from born
                        x2: {scale: "xscale", field: "died_adjusted"},  // to died
                        y: {scale: "yscale", field: "timeline_id"},
                        fill: {scale: "kindscale", field: "kind"},
                        height: {signal: "timelineBarHeight"}
                    },
                    update: {
                        x: {scale: "xscale", field: "born_adjusted"},  // from born
                        x2: {scale: "xscale", field: "died_adjusted"},  // to died
                    },
                }
            },
            {
                name: "personbar",
                // invisible bar to overlay the other marks for a person 
                // for hover to work over the full width of the chart
                type: "rect",
                from: {data: "people"},
                encode: {
                    enter: {
                        x: {value: 0},
                        width: {signal: "width"},
                        y: {scale: "yscale", field: "timeline_id", offset: -15},  // offset to start it above the label
                        height: {signal: "personHeight + 15"},
                        fill: {value: "red"},
                        fillOpacity: {value: 0},  // 0 makes it invisible
                        tooltip: {
                            signal: "{'Born': datum.birth_tooltip, 'Died': datum.death_tooltip}"
                        },
                    },
                    update: {
                        width: {signal: "width"},
                    },
                }
            },
            {
                name: "undated-marriage-lines",
                // Connect spouses whose marriage has no usable date.
                // Position each connector in the area left of the dated timeline.
                type: "rule",
                from: {data: "undatedMarriageEvents"},
                encode: {
                    enter: {
                        stroke: {value: "slategrey"},
                        strokeWidth: {value: 1},
                        tooltip: {
                            signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {
                            signal: "undatedMarriageWidth - " +
                                    "undatedMarriageMargin - " +
                                    "datum.undatedIndex * undatedMarriageSpacing"
                        },
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        },
                        y2: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "undated-marriage-line-hover",
                // Wider invisible target for the marriage tooltip.
                type: "rule",
                from: {data: "undatedMarriageEvents"},
                encode: {
                    enter: {
                        stroke: {value: "transparent"},
                        strokeWidth: {value: 7},
                        tooltip: {
                            signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {
                            signal: "undatedMarriageWidth - " +
                                    "undatedMarriageMargin - " +
                                    "datum.undatedIndex * undatedMarriageSpacing"
                        },
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        },
                        y2: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "undated-marriage-marker-person1",
                type: "symbol",
                from: {data: "undatedMarriageEvents"},
                encode: {
                    enter: {
                        size: {value: 20},
                        shape: {value: "circle"},
                        fill: {value: "black"},
                        tooltip: {
                            signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {
                            signal: "undatedMarriageWidth - " +
                                    "undatedMarriageMargin - " +
                                    "datum.undatedIndex * undatedMarriageSpacing"
                        },
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "undated-marriage-marker-person2",
                type: "symbol",
                from: {data: "undatedMarriageEvents"},
                encode: {
                    enter: {
                        size: {value: 20},
                        shape: {value: "circle"},
                        fill: {value: "black"},
                        tooltip: {
                            signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {
                            signal: "undatedMarriageWidth - " +
                                    "undatedMarriageMargin - " +
                                    "datum.undatedIndex * undatedMarriageSpacing"
                        },
                        y: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "marriage-lines",
                // vertical lines connecting marriage partners at the marriage date
                type: "rule",
                from: {data: "datedMarriageEvents"},
                encode: {
                    enter: {
                        stroke: {value: "slategrey"},
                        strokeWidth: {value: 1},
                        tooltip: {
                        signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {scale: "xscale", field: "date_adjusted"},
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        },
                        y2: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "marriage-line-hover",
                // provide a bigger target for the marriage line tooltip
                type: "rule",
                from: {data: "datedMarriageEvents"},
                encode: {
                    enter: {
                        stroke: {value: "transparent"},
                        strokeWidth: {value: 7},
                        tooltip: {
                        signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {scale: "xscale", field: "date_adjusted"},
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        },
                        y2: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "marriage-marker-person1",
                type: "symbol",
                from: {data: "datedMarriageEvents"},
                encode: {
                    enter: {
                        size: {value: 20},
                        shape: {value: "circle"},
                        fill: {value: "black"},
                        tooltip: {
                        signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {scale: "xscale", field: "date_adjusted"},
                        y: {
                            scale: "yscale",
                            field: "person1_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "marriage-marker-person2",
                type: "symbol",
                from: {data: "datedMarriageEvents"},
                encode: {
                    enter: {
                        size: {value: 20},
                        shape: {value: "circle"},
                        fill: {value: "black"},
                        tooltip: {
                        signal: marriageTooltipExpr
                        }
                    },
                    update: {
                        x: {scale: "xscale", field: "date_adjusted"},
                        y: {
                            scale: "yscale",
                            field: "person2_timeline_id",
                            offset: {signal: "timelineBarCentre"}
                        }
                    }
                }
            },
            {
                name: "personlabel",
                // this mark is the text label on a person timeline
                // it goes after personbar so that the url hover works on the label
                type: "text",
                from: {data: "people"},
                encode: {
                    enter: {
                        x: [
                            // if only one marker and it's in the right half of chart then position x to the marker
                            // and offset a bit to avoid born or died line clash.
                            // In Vega the first condition in the array that evaluates to true will be applied, subsequent conditions will be ignored.
                            // If none of the previous are true, the final condition (which can act as a default) will be applied.
                            {test: bothDatesRight, scale: "xscale", field: "died_adjusted", offset: -3},
                            {test: deathOnlyRight, scale: "xscale", field: "died_adjusted", offset: -5},
                            {test: birthOnlyRight, scale: "xscale", field: "born_adjusted", offset: -4},
                            {scale: "xscale", field: "born_adjusted", offset: 2}
                        ],
                        align: [  // right align if x is past the midpoint
                            {test: bothDatesRight, value: "right"},
                            {test: deathOnlyRight, value: "right"},
                            {test: birthOnlyRight, value: "right"},
                            {value: "left"}
                        ],
                        y: {scale: "yscale", field: "timeline_id", offset: {signal: "personLabelOffset"}},
                        fill: {value: "#000"},
                        text: {field: "plabel1", type: "nominal"},
                        fontSize: {signal: "labelFontSize"},
                        fontWeight: [
                            // Make bold if reln is "subject", ie label is for the subject person
                            {test: "datum.pc_reln === 'subject'", value: "bold"}
                        ],
                        tooltip: {
                            signal: "{'Born': datum.birth_tooltip, 'Died': datum.death_tooltip}"
                        },
                        href: {field: "opurl", type: "nominal"}
                    },
                    update: {
                        x: [
                            {test: bothDatesRight, scale: "xscale", field: "died_adjusted", offset: -3},
                            {test: deathOnlyRight, scale: "xscale", field: "died_adjusted", offset: -5},
                            {test: birthOnlyRight, scale: "xscale", field: "born_adjusted", offset: -4},
                            {scale: "xscale", field: "born_adjusted", offset: 2}
                        ],
                        align: [
                            {test: bothDatesRight, value: "right"},
                            {test: deathOnlyRight, value: "right"},
                            {test: birthOnlyRight, value: "right"},
                            {value: "left"}
                        ],
                        fontSize: {signal: "labelFontSize"},
                    },
                    hover: {
                        cursor: {value: "pointer"}
                    }
                }
            },
            {
                name: "born-line",
                type: "rule",
                from: {data: "hasbirth"},
                encode: {
                    enter: {
                        x: {scale: "xscale", field: "born_adjusted"},
                        y: {signal: "-topAxisOffset"},
                        y2: {signal: "peopleHeight"},
                        color: {value: "lightgray"},
                        strokeDash: {value: [4, 4]}
                    },
                    update: {
                        // This is the test condition to make the born line visible when timebar is hovered.
                        // It first checks if the hovered signal is not null and
                        // if the label of the hovered datum matches the label of the current datum.
                        x: {scale: "xscale", field: "born_adjusted"},
                        // strokeOpacity: [{test: "hovered && hovered.born_adjusted === datum.born_adjusted", value: 1}, {value: 0}]
                        strokeOpacity: [
                            {
                                test: "showTimeHints && hovered && hovered.born_adjusted === datum.born_adjusted",
                                value: 1
                            },
                            {value: 0}
                        ]
                    }
                }
            },
            {
                name: "died-line",
                type: "rule",
                from: {data: "hasdeath"},
                encode: {
                    enter: {
                        x: {scale: "xscale", field: "died_adjusted"},
                        y: {signal: "-topAxisOffset"},
                        y2: {signal: "peopleHeight"},
                        strokeDash: {value: [4, 4]},
                        color: {value: "lightgray"}
                    },
                    update: {  // similar test as for born line
                        x: {scale: "xscale", field: "died_adjusted"},
                        // strokeOpacity: [{test: "hovered && hovered.died_adjusted === datum.died_adjusted", value: 1}, {value: 0}]
                        strokeOpacity: [
                            {
                                test: "showTimeHints && hovered && hovered.died_adjusted === datum.died_adjusted",
                                value: 1
                            },
                            {value: 0}
                        ]
                    }
                }
            },
            {
                data: [],
                name: "families",  // not used yet, was going to group famillies
                type: "group",
                from: {
                    facet: {
                        data: "people",
                        name: "people",
                        groupby: "fam_handle"
                    }
                }
            }
        ]
    };
}
