(function () {
    "use strict";

    var availableThemes = [
        'dwr_default',
        'dwr_mainz',
        'dwr_cerulean',
        'dwr_flatly',
        'dwr_journal',
        'dwr_readable',
        'dwr_united'
    ];

    // Keep theme preferences separate for each generated website.
    var themeStorageKey = 'dwr_theme:' + new URL(Dwr.toRoot).pathname;
    Dwr.themeStorageKey = themeStorageKey;
    // Separate website-specific preference for enhanced borders.
    var bordersStorageKey = 'dwr_borders:' + new URL(Dwr.toRoot).pathname;
    Dwr.bordersStorageKey = bordersStorageKey;

    var savedTheme = null;

    try {
        savedTheme = localStorage.getItem(themeStorageKey);
    } catch (e) {
        // Local storage may be unavailable.
    }

    var defaultTheme = window.DEFAULT_WEBSITE_THEME || 'dwr_default';

    var selectedTheme =
        availableThemes.indexOf(savedTheme) !== -1
            ? savedTheme
            : defaultTheme;

    if (availableThemes.indexOf(selectedTheme) === -1) {
        selectedTheme = 'dwr_default';
    }

    var themeName = selectedTheme.replace(/^dwr_/, '');

    var scriptFolder = Dwr.toRoot + 'data/';

    function loadThemeCss(path) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = scriptFolder + path;
        document.head.appendChild(link);
    }

    loadThemeCss('themes/bootstrap/' + themeName + '.css');

    if (selectedTheme === 'dwr_mainz') {
        loadThemeCss('themes/mainz/dwr_styles.css');
    } else {
        loadThemeCss('themes/default/dwr_styles.css');
    }

     // Apply the visitor's enhanced borders preference.
    var bordersEnabled = false;

    try {
        bordersEnabled = localStorage.getItem(bordersStorageKey) === 'true';
    } catch (e) {
        // Local storage may be unavailable.
    }

    if (bordersEnabled) {
        loadThemeCss('dwr_borders.css');
    }
})();