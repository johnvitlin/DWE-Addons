#
# PDF Thumbnailer - A PDF thumbnail generator for Gramps
#
# Copyright (C) 2026 John Vitlin
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""
PDF thumbnail generation using Poppler's pdftoppm.
"""

import logging
import os
import shutil
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path

from gramps.gen.const import THUMBSCALE, THUMBSCALE_LARGE, SIZE_LARGE
from gramps.gen.plug import Thumbnailer

LOG = logging.getLogger(".thumbnail")


# Cache the Poppler executable path to avoid repeated searches.
@lru_cache(maxsize=1)
def find_pdftoppm():
    """Locate Poppler's pdftoppm executable."""

    configured = os.environ.get("PDFTHUMBNAILER_PDFTOPPM")

    if configured:
        if os.path.isfile(configured):
            return configured
        LOG.warning(
            "Configured Poppler executable not found: %s",
            configured,
        )

    executable = shutil.which("pdftoppm")
    if executable:
        return executable

    # Search common Windows Poppler installation directories.
    if os.name == "nt":
        roots = [
            Path("C:/Poppler"),
            Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Poppler",
            Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)")) / "Poppler",
            Path("C:/Tools/Poppler"),
        ]

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            roots.append(Path(local_app_data) / "Poppler")

        for root in roots:
            candidates = [
                root / "Library/bin/pdftoppm.exe",
                root / "bin/pdftoppm.exe",
            ]

            if root.is_dir():
                try:
                    for version_dir in root.iterdir():
                        if version_dir.is_dir():
                            candidates.extend([
                                version_dir / "Library/bin/pdftoppm.exe",
                                version_dir / "bin/pdftoppm.exe",
                            ])
                except OSError as err:
                    LOG.debug(
                        "Cannot search Poppler directory %s: %s",
                        root, err,
                    )

            for candidate in candidates:
                if candidate.is_file():
                    return str(candidate)

    return None


class PDFThumbnailer(Thumbnailer):
    """Generate a PNG thumbnail from the first page of a PDF."""

    def is_supported(self, mime_type):
        return mime_type == "application/pdf"

    def run(self, mime_type, src_file, dest_file, size, rectangle):
        if not self.is_supported(mime_type):
            return False

        pdftoppm = find_pdftoppm()

        if not pdftoppm:
            LOG.warning(
                "Poppler pdftoppm executable not found. "
                "PDF thumbnails cannot be generated. "
                "Install Poppler or configure PDFTHUMBNAILER_PDFTOPPM."
            )
            return False

        thumbscale = (
            THUMBSCALE_LARGE if size == SIZE_LARGE else THUMBSCALE
        )

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                output_prefix = os.path.join(temp_dir, "pdf-thumb")
                output_png = output_prefix + ".png"

                command = [
                    pdftoppm,
                    "-f", "1",
                    "-l", "1",
                    "-singlefile",
                    "-scale-to", str(int(thumbscale)),
                    "-png",
                    src_file,
                    output_prefix,
                ]

                subprocess.run(
                    command,
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    timeout=30,
                )

                os.replace(output_png, dest_file)

            return True

        except (OSError, subprocess.SubprocessError) as err:
            LOG.warning("PDF thumbnail generation failed: %s", err)
            return False
        